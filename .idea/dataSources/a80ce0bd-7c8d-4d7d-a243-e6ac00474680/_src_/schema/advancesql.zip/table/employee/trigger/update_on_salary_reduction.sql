CREATE TRIGGER update_on_salary_reduction
AFTER UPDATE ON employee
FOR EACH ROW
  begin
if old.salary > new.salary then
insert into transaction_record
set employee_name =  old.employee_name,
update_by = 'admin',
changed_salary = new.salary,
update_date = now();
end if ;
end;
