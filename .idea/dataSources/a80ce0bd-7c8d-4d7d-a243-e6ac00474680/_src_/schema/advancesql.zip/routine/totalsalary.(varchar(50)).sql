CREATE FUNCTION totalsalary(deptname VARCHAR(50))
  RETURNS INT
  begin
declare totalsalary int;
select sum(salary) into totalsalary from employee
where dept = deptname
;
return totalsalary;
end;
